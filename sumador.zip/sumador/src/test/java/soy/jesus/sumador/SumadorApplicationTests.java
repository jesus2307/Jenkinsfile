package soy.jesus.sumador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SumadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
