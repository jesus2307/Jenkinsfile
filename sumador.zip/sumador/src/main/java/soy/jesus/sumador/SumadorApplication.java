package soy.jesus.sumador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SumadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SumadorApplication.class, args);
	}

}
